/*
 * splash.h
 *
 * Created: 6/29/2020 5:39:10 PM
 *  Author: bench
 */ 


#ifndef SPLASH_H
#define SPLASH_H

void drawKare(int emotion);
void splashScreen(void);


#endif /* SPLASH_H_ */