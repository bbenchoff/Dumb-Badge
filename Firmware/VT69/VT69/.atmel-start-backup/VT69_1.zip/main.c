#include <atmel_start.h>
#include <stdio.h>


int main(void)
{
	int i = 0;
	
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		i++;
		printf("%i ",i);
		
	}
}
